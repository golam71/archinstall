.. _archinstall.Installer:

archinstall.Installer
=====================

The installer is the main class for accessing a installation-instance.
You can look at this class as the installation you have or will perform.

Anything related to **inside** the installation, will be found in this class.

.. autofunction:: archinstall.Installer
