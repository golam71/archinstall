import archinstall

if __name__ == '__main__':
	archinstall.run_as_a_module()
